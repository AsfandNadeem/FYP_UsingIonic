(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~post-post-module~tabs-tabs-module"],{

/***/ "./src/app/post/post.module.ts":
/*!*************************************!*\
  !*** ./src/app/post/post.module.ts ***!
  \*************************************/
/*! exports provided: PostPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PostPageModule", function() { return PostPageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _post_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./post.page */ "./src/app/post/post.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var routes = [
    {
        path: '',
        component: _post_page__WEBPACK_IMPORTED_MODULE_5__["PostPage"]
    }
];
var PostPageModule = /** @class */ (function () {
    function PostPageModule() {
    }
    PostPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routes)
            ],
            declarations: [_post_page__WEBPACK_IMPORTED_MODULE_5__["PostPage"]]
        })
    ], PostPageModule);
    return PostPageModule;
}());



/***/ }),

/***/ "./src/app/post/post.page.html":
/*!*************************************!*\
  !*** ./src/app/post/post.page.html ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n    <ion-card *ngFor=\"let post of posts\">\n\n        <ion-card-header>\n            <ion-list style=\"list-style: none; display: flex;\">\n                <ion-item lines=\"none\">\n                    <ion-avatar slot=\"start\">\n                        <img [src]= \"post.profileimg\">\n                    </ion-avatar>\n                </ion-item>\n                <ion-item>\n                    <ion-card-title>{{post.username}}</ion-card-title>\n                </ion-item>\n\n           <ion-item>\n            <ion-card-subtitle>{{ post.title }}</ion-card-subtitle>\n           </ion-item>\n            </ion-list>\n        </ion-card-header>\n        <img [hidden]=\"!post.imagePath\" [src]=\"post.imagePath\" [alt]=\"post.title\" >\n        <ion-card-content>\n            <strong>{{post.content}}</strong>\n            <br/>\n            <strong>Date: </strong>{{ post.createdAt | date:'MMM dd, yyyy' }}\n        </ion-card-content>\n    </ion-card>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/post/post.page.scss":
/*!*************************************!*\
  !*** ./src/app/post/post.page.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3Bvc3QvcG9zdC5wYWdlLnNjc3MifQ== */"

/***/ }),

/***/ "./src/app/post/post.page.ts":
/*!***********************************!*\
  !*** ./src/app/post/post.page.ts ***!
  \***********************************/
/*! exports provided: PostPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PostPage", function() { return PostPage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _posts_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./posts.service */ "./src/app/post/posts.service.ts");
/* harmony import */ var _auth_auth_service_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../auth/auth-service.service */ "./src/app/auth/auth-service.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var PostPage = /** @class */ (function () {
    function PostPage(postsService, authService) {
        this.postsService = postsService;
        this.authService = authService;
        this.posts = [];
        this.isLoading = false;
        this.totalPosts = 0;
        this.postsPerPage = 5;
        this.currentPage = 1;
        this.newComment = [];
        this.pageSizeOptions = [1, 2, 5, 10];
        this.userIsAuthenticated = false;
    }
    PostPage.prototype.ngOnInit = function () {
        var _this = this;
        this.isLoading = true;
        this.postsService.getPosts();
        this.userId = this.authService.getUserId();
        // this.username = this.authService.getName();
        console.log(localStorage.getItem('profileimg'));
        this.profileimg = localStorage.getItem('profileimg');
        this.username = localStorage.getItem('username');
        this.postsSub = this.postsService.getPostUpdateListener()
            .subscribe(function (postData) {
            _this.isLoading = false;
            _this.totalPosts = postData.postCount;
            // this.username = this.authService.getName();
            _this.posts = postData.posts;
            console.log(_this.posts);
        });
        this.userIsAuthenticated = this.authService.getIsAuth();
        this.authStatusSub = this.authService
            .getAuthStatusListener()
            .subscribe(function (isAuthenticated) {
            _this.userIsAuthenticated = isAuthenticated;
            _this.userId = _this.authService.getUserId();
        });
    };
    PostPage.prototype.ngOnDestroy = function () {
        this.postsSub.unsubscribe();
        this.authStatusSub.unsubscribe();
    };
    PostPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-post',
            template: __webpack_require__(/*! ./post.page.html */ "./src/app/post/post.page.html"),
            styles: [__webpack_require__(/*! ./post.page.scss */ "./src/app/post/post.page.scss")]
        }),
        __metadata("design:paramtypes", [_posts_service__WEBPACK_IMPORTED_MODULE_1__["PostsService"], _auth_auth_service_service__WEBPACK_IMPORTED_MODULE_2__["AuthServiceService"]])
    ], PostPage);
    return PostPage;
}());



/***/ }),

/***/ "./src/app/post/posts.service.ts":
/*!***************************************!*\
  !*** ./src/app/post/posts.service.ts ***!
  \***************************************/
/*! exports provided: PostsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PostsService", function() { return PostsService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var PostsService = /** @class */ (function () {
    function PostsService(http, router) {
        this.http = http;
        this.router = router;
        this.posts = [];
        this.postsUpdated = new rxjs__WEBPACK_IMPORTED_MODULE_1__["Subject"]();
    }
    PostsService.prototype.getPosts = function () {
        var _this = this;
        // const queryParams = `?pagesize=${postsPerPage}&page=${currentPage}`; // `` backtips are for dynamically adding values into strings
        this.http
            .get('http://localhost:3000/api/posts')
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (postData) {
            return { posts: postData.posts.map(function (post) {
                    return {
                        profileimg: post.profileimg,
                        title: post.title,
                        content: post.content,
                        id: post._id,
                        username: post.username,
                        creator: post.creator,
                        likes: post.likes,
                        category: post.category,
                        commentsNo: post.commentsNo,
                        comments: post.comments,
                        dislikes: post.dislikes,
                        createdAt: post.createdAt,
                        imagePath: post.imagePath
                    };
                }), maxPosts: postData.maxPosts };
        })) // change rterieving data
            .subscribe(function (transformedPostData) {
            _this.posts = transformedPostData.posts;
            _this.postsUpdated.next({
                posts: _this.posts.slice(),
                postCount: transformedPostData.maxPosts
            });
        }); // subscribe is to liosten
    };
    PostsService.prototype.getPostUpdateListener = function () {
        return this.postsUpdated.asObservable();
    };
    PostsService.prototype.addPost = function (title, content, image, category) {
        var _this = this;
        var postData = new FormData();
        postData.append('title', title);
        postData.append('content', content);
        postData.append('image', image, title);
        postData.append('category', category);
        // postData.append('username', localStorage.getItem('username'));
        // postData.append('profileimg', profileimg);
        console.log(postData);
        this.http
            .post('http://localhost:3000/api/posts', postData)
            .subscribe(function (responseData) {
            _this.router.navigate(['/messages']);
        });
    };
    PostsService.prototype.getPost = function (id) {
        return this.http.get('http://localhost:3000/api/posts/' + id);
    };
    PostsService.prototype.updatePost = function (id, title, content, image) {
        var _this = this;
        var postData;
        if (typeof (image) === 'object') {
            postData = new FormData();
            postData.append('id', id);
            postData.append('title', title);
            postData.append('content', content);
            postData.append('username', localStorage.getItem('username'));
            postData.append('image', image, title);
        }
        else {
            postData = {
                id: id,
                title: title,
                content: content,
                category: null,
                creator: null,
                likes: null,
                dislikes: null,
                comments: null,
                commentsNo: null,
                createdAt: null,
                username: localStorage.getItem('username'),
                imagePath: image
            };
        }
        this.http.put('http://localhost:3000/api/posts/' + id, postData)
            .subscribe(function (response) {
            _this.router.navigate(['/messages']);
        });
    };
    PostsService.prototype.deletePost = function (postId) {
        return this.http
            .delete('http://localhost:3000/api/posts/' + postId);
    };
    // postComment(id, comment) {
    //   const postData = {
    //     id: id,
    //     comment: comment
    //   };
    //   return this.http.post('http://localhost:3000/api/posts/comment/' + id, postData);
    // }
    PostsService.prototype.likePost = function (id) {
        // @ts-ignore
        return this.http.put('http://localhost:3000/api/posts/likePost/' + id);
    };
    PostsService.prototype.dislikePost = function (id) {
        // @ts-ignore
        return this.http.put('http://localhost:3000/api/posts/dislikePost/' + id);
    };
    PostsService.prototype.addComment = function (id, comment) {
        var postdata = {
            id: id,
            comment: comment
        };
        // @ts-ignore
        return this.http.put('http://localhost:3000/api/posts/comment/' + id, postdata);
    };
    PostsService.prototype.archivepost = function (id) {
        // @ts-ignore
        return this.http.put('http://localhost:3000/api/posts/archivePost/' + id);
    };
    PostsService.prototype.removearchivePost = function (postId) {
        return this.http
            .delete('http://localhost:3000/api/posts/archives/' + postId);
    };
    PostsService.prototype.getarchivePosts = function (postsPerPage, currentPage) {
        var _this = this;
        var queryParams = "?pagesize=" + postsPerPage + "&page=" + currentPage; // `` backtips are for dynamically adding values into strings
        this.http
            .get('http://localhost:3000/api/posts/archives' + queryParams)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (postData) {
            return { posts: postData.posts.map(function (post) {
                    return {
                        profileimg: post.profileimg,
                        title: post.title,
                        content: post.content,
                        id: post._id,
                        username: post.username,
                        creator: post.creator,
                        likes: post.likes,
                        category: post.category,
                        commentsNo: post.commentsNo,
                        comments: post.comments,
                        dislikes: post.dislikes,
                        createdAt: post.createdAt,
                        imagePath: post.imagePath
                    };
                }), maxPosts: postData.maxPosts };
        })) // change rterieving data
            .subscribe(function (transformedPostData) {
            _this.posts = transformedPostData.posts;
            _this.postsUpdated.next({
                posts: _this.posts.slice(),
                postCount: transformedPostData.maxPosts
            });
        }); // subscribe is to liosten
    };
    PostsService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({ providedIn: 'root' }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]])
    ], PostsService);
    return PostsService;
}());



/***/ })

}]);
//# sourceMappingURL=default~post-post-module~tabs-tabs-module.js.map