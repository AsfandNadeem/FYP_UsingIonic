(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~post-post-module~tabs-tabs-module"],{

/***/ "./src/app/post/post.module.ts":
/*!*************************************!*\
  !*** ./src/app/post/post.module.ts ***!
  \*************************************/
/*! exports provided: PostPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PostPageModule", function() { return PostPageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _post_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./post.page */ "./src/app/post/post.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var routes = [
    {
        path: '',
        component: _post_page__WEBPACK_IMPORTED_MODULE_5__["PostPage"]
    }
];
var PostPageModule = /** @class */ (function () {
    function PostPageModule() {
    }
    PostPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routes)
            ],
            declarations: [_post_page__WEBPACK_IMPORTED_MODULE_5__["PostPage"]]
        })
    ], PostPageModule);
    return PostPageModule;
}());



/***/ }),

/***/ "./src/app/post/post.page.html":
/*!*************************************!*\
  !*** ./src/app/post/post.page.html ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n    <ion-card>\n        <ion-row justify-content-center>\n            <ion-col align-self-center size-md=\"6\" size-lg=\"5\" size-xs=\"12\">\n        <form #form=\"ngForm\" novalidate (ngSubmit)=\"onSavePost(form)\" >\n\n            <ion-input\n            type=\"text\"\n            required\n            [(ngModel)]=\"title\"\n            ngModel\n            #titleInput=\"ngModel\"\n            name=\"title\"\n            placeholder=\"Title\">\n            </ion-input>\n\n                <ion-input\n                type=\"text\"\n                rows=\"4\"\n                required\n                [(ngModel)]=\"content\"\n                ngModel\n                #contentInput=\"ngModel\"\n                name=\"content\"\n                placeholder=\"Post Content\"\n                ></ion-input>\n\n            <ion-select\n            required\n            [(ngModel)]=\"cname\"\n            ngModel\n            placeholder=\"Category\"\n            #cnameInput = \"ngModel\"\n            name = \"cname\">\n\n            <ion-select-option *ngFor=\"let category of categories\" [value]=\"category\">\n            {{category}}\n            </ion-select-option>\n\n            </ion-select>\n\n            <ion-button\n                    type=\"submit\">Save Post</ion-button>\n        </form>\n            </ion-col></ion-row>\n    </ion-card>\n\n\n    <ion-card *ngFor=\"let post of posts\">\n\n        <ion-card-header>\n            <ion-list style=\"list-style: none; display: flex;\">\n                <ion-item lines=\"none\">\n                    <ion-avatar slot=\"start\">\n                        <!--<img [src]= \"post.profileimg\">-->\n                        <img [src]= \"post.profileimg.replace('localhost', '192.168.10.7')\">\n                    </ion-avatar>\n                </ion-item>\n                <ion-item>\n                    <ion-card-title>{{post.username}}</ion-card-title>\n                </ion-item>\n\n           <ion-item>\n            <ion-card-subtitle>{{ post.title }}</ion-card-subtitle>\n           </ion-item>\n            </ion-list>\n        </ion-card-header>\n        <!--<img [hidden]=\"!post.imagePath\" [src]=\"post.imagePath\" [alt]=\"post.title\" >-->\n        <img  *ngIf=\"post.imagePath\" [hidden]=\"!post.imagePath\" [src]=\"post.imagePath.replace('localhost', '192.168.10.7')\" [alt]=\"post.title\" >\n        <ion-card-content>\n            <strong>{{post.content}}</strong>\n            <br/>\n            <strong>Date: </strong>{{ post.createdAt | date:'MMM dd, yyyy' }}\n        </ion-card-content>\n    </ion-card>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/post/post.page.scss":
/*!*************************************!*\
  !*** ./src/app/post/post.page.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-row {\n  height: 100%; }\n\nion-col {\n  border: 1px solid #488aff;\n  background: #fff; }\n\nion-button {\n  font-weight: 300; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcG9zdC9GOlxcY29tc2F0c19zb2NpYWxfbW9iaWxlL3NyY1xcYXBwXFxwb3N0XFxwb3N0LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFHQTtFQUNFLFlBSGMsRUFBQTs7QUFNaEI7RUFDRSx5QkFBeUI7RUFDekIsZ0JBVGdCLEVBQUE7O0FBWWxCO0VBQ0UsZ0JBQWdCLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9wb3N0L3Bvc3QucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiJHdoaXRlLWNvbG9yOiAjZmZmO1xyXG4kaGVpZ2h0MTAwOiAxMDAlO1xyXG5cclxuaW9uLXJvdyB7XHJcbiAgaGVpZ2h0OiAkaGVpZ2h0MTAwO1xyXG59XHJcblxyXG5pb24tY29sIHtcclxuICBib3JkZXI6IDFweCBzb2xpZCAjNDg4YWZmO1xyXG4gIGJhY2tncm91bmQ6ICR3aGl0ZS1jb2xvcjtcclxufVxyXG5cclxuaW9uLWJ1dHRvbiB7XHJcbiAgZm9udC13ZWlnaHQ6IDMwMDtcclxufVxyXG4iXX0= */"

/***/ }),

/***/ "./src/app/post/post.page.ts":
/*!***********************************!*\
  !*** ./src/app/post/post.page.ts ***!
  \***********************************/
/*! exports provided: PostPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PostPage", function() { return PostPage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _posts_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./posts.service */ "./src/app/post/posts.service.ts");
/* harmony import */ var _auth_auth_service_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../auth/auth-service.service */ "./src/app/auth/auth-service.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var PostPage = /** @class */ (function () {
    function PostPage(postsService, authService) {
        this.postsService = postsService;
        this.authService = authService;
        this.posts = [];
        this.isLoading = false;
        this.totalPosts = 0;
        this.postsPerPage = 5;
        this.currentPage = 1;
        this.newComment = [];
        this.pageSizeOptions = [1, 2, 5, 10];
        this.userIsAuthenticated = false;
        this.categories = ['General', localStorage.getItem('department')];
    }
    PostPage.prototype.ngOnInit = function () {
        var _this = this;
        this.isLoading = true;
        this.postsService.getPosts();
        this.userId = this.authService.getUserId();
        // this.username = this.authService.getName();
        console.log(localStorage.getItem('profileimg'));
        this.profileimg = localStorage.getItem('profileimg');
        this.username = localStorage.getItem('username');
        this.postsSub = this.postsService.getPostUpdateListener()
            .subscribe(function (postData) {
            _this.isLoading = false;
            _this.totalPosts = postData.postCount;
            // this.username = this.authService.getName();
            _this.posts = postData.posts;
            console.log(_this.posts);
        });
        this.userIsAuthenticated = this.authService.getIsAuth();
        this.authStatusSub = this.authService
            .getAuthStatusListener()
            .subscribe(function (isAuthenticated) {
            _this.userIsAuthenticated = isAuthenticated;
            _this.userId = _this.authService.getUserId();
        });
    };
    PostPage.prototype.onSavePost = function (form) {
        var _this = this;
        console.log(form.value.title + ' ' + form.value.content + ' ' + form.value.cname);
        this.postsService.addPost(form.value.title, form.value.content, form.value.cname).subscribe(function () {
            _this.postsService.getPosts();
        });
        form.reset();
    };
    PostPage.prototype.ngOnDestroy = function () {
        this.postsSub.unsubscribe();
        this.authStatusSub.unsubscribe();
    };
    PostPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-post',
            template: __webpack_require__(/*! ./post.page.html */ "./src/app/post/post.page.html"),
            styles: [__webpack_require__(/*! ./post.page.scss */ "./src/app/post/post.page.scss")]
        }),
        __metadata("design:paramtypes", [_posts_service__WEBPACK_IMPORTED_MODULE_1__["PostsService"], _auth_auth_service_service__WEBPACK_IMPORTED_MODULE_2__["AuthServiceService"]])
    ], PostPage);
    return PostPage;
}());



/***/ }),

/***/ "./src/app/post/posts.service.ts":
/*!***************************************!*\
  !*** ./src/app/post/posts.service.ts ***!
  \***************************************/
/*! exports provided: PostsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PostsService", function() { return PostsService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var PostsService = /** @class */ (function () {
    function PostsService(http, router) {
        this.http = http;
        this.router = router;
        this.posts = [];
        this.postsUpdated = new rxjs__WEBPACK_IMPORTED_MODULE_1__["Subject"]();
    }
    PostsService.prototype.getPosts = function () {
        var _this = this;
        // const queryParams = `?pagesize=${postsPerPage}&page=${currentPage}`; // `` backtips are for dynamically adding values into strings
        this.http
            .get('http://192.168.10.7:3000/api/posts')
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (postData) {
            return { posts: postData.posts.map(function (post) {
                    return {
                        profileimg: post.profileimg,
                        title: post.title,
                        content: post.content,
                        id: post._id,
                        username: post.username,
                        creator: post.creator,
                        likes: post.likes,
                        category: post.category,
                        commentsNo: post.commentsNo,
                        comments: post.comments,
                        dislikes: post.dislikes,
                        createdAt: post.createdAt,
                        imagePath: post.imagePath
                    };
                }), maxPosts: postData.maxPosts };
        })) // change rterieving data
            .subscribe(function (transformedPostData) {
            _this.posts = transformedPostData.posts;
            _this.postsUpdated.next({
                posts: _this.posts.slice(),
                postCount: transformedPostData.maxPosts
            });
        }); // subscribe is to liosten
    };
    PostsService.prototype.getPostUpdateListener = function () {
        return this.postsUpdated.asObservable();
    };
    PostsService.prototype.addPost = function (title, content, category) {
        // const postData =  new FormData();
        // postData.append('title', title);
        //   postData.append('content', content);
        // // postData.append('image', image, title);
        // postData.append( 'category', category);
        // postData.append('username', localStorage.getItem('username'));
        // postData.append('profileimg', profileimg);
        // console.log(postData);
        return this.http
            .post('http://192.168.10.7:3000/api/posts/postmobile', { title: title, content: content, category: category });
    };
    PostsService.prototype.getPost = function (id) {
        return this.http.get('http://localhost:3000/api/posts/' + id);
    };
    PostsService.prototype.updatePost = function (id, title, content, image) {
        var _this = this;
        var postData;
        if (typeof (image) === 'object') {
            postData = new FormData();
            postData.append('id', id);
            postData.append('title', title);
            postData.append('content', content);
            postData.append('username', localStorage.getItem('username'));
            postData.append('image', image, title);
        }
        else {
            postData = {
                id: id,
                title: title,
                content: content,
                category: null,
                creator: null,
                likes: null,
                dislikes: null,
                comments: null,
                commentsNo: null,
                createdAt: null,
                username: localStorage.getItem('username'),
                imagePath: image
            };
        }
        this.http.put('http://localhost:3000/api/posts/' + id, postData)
            .subscribe(function (response) {
            _this.router.navigate(['/messages']);
        });
    };
    PostsService.prototype.deletePost = function (postId) {
        return this.http
            .delete('http://localhost:3000/api/posts/' + postId);
    };
    // postComment(id, comment) {
    //   const postData = {
    //     id: id,
    //     comment: comment
    //   };
    //   return this.http.post('http://localhost:3000/api/posts/comment/' + id, postData);
    // }
    PostsService.prototype.likePost = function (id) {
        // @ts-ignore
        return this.http.put('http://localhost:3000/api/posts/likePost/' + id);
    };
    PostsService.prototype.dislikePost = function (id) {
        // @ts-ignore
        return this.http.put('http://localhost:3000/api/posts/dislikePost/' + id);
    };
    PostsService.prototype.addComment = function (id, comment) {
        var postdata = {
            id: id,
            comment: comment
        };
        // @ts-ignore
        return this.http.put('http://localhost:3000/api/posts/comment/' + id, postdata);
    };
    PostsService.prototype.archivepost = function (id) {
        // @ts-ignore
        return this.http.put('http://localhost:3000/api/posts/archivePost/' + id);
    };
    PostsService.prototype.removearchivePost = function (postId) {
        return this.http
            .delete('http://localhost:3000/api/posts/archives/' + postId);
    };
    PostsService.prototype.getarchivePosts = function (postsPerPage, currentPage) {
        var _this = this;
        var queryParams = "?pagesize=" + postsPerPage + "&page=" + currentPage; // `` backtips are for dynamically adding values into strings
        this.http
            .get('http://localhost:3000/api/posts/archives' + queryParams)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (postData) {
            return { posts: postData.posts.map(function (post) {
                    return {
                        profileimg: post.profileimg,
                        title: post.title,
                        content: post.content,
                        id: post._id,
                        username: post.username,
                        creator: post.creator,
                        likes: post.likes,
                        category: post.category,
                        commentsNo: post.commentsNo,
                        comments: post.comments,
                        dislikes: post.dislikes,
                        createdAt: post.createdAt,
                        imagePath: post.imagePath
                    };
                }), maxPosts: postData.maxPosts };
        })) // change rterieving data
            .subscribe(function (transformedPostData) {
            _this.posts = transformedPostData.posts;
            _this.postsUpdated.next({
                posts: _this.posts.slice(),
                postCount: transformedPostData.maxPosts
            });
        }); // subscribe is to liosten
    };
    PostsService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({ providedIn: 'root' }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]])
    ], PostsService);
    return PostsService;
}());



/***/ })

}]);
//# sourceMappingURL=default~post-post-module~tabs-tabs-module.js.map