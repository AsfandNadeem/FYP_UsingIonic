(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./node_modules/@ionic/core/dist/esm/es5/build lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$":
/*!*********************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/es5/build lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ namespace object ***!
  \*********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./0owmtgfs.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/0owmtgfs.entry.js",
		"common",
		58
	],
	"./0owmtgfs.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/0owmtgfs.sc.entry.js",
		"common",
		59
	],
	"./0utrggve.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/0utrggve.entry.js",
		"common",
		60
	],
	"./0utrggve.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/0utrggve.sc.entry.js",
		"common",
		61
	],
	"./3hf0d5sl.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/3hf0d5sl.entry.js",
		"common",
		62
	],
	"./3hf0d5sl.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/3hf0d5sl.sc.entry.js",
		"common",
		63
	],
	"./47ctf96j.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/47ctf96j.entry.js",
		0,
		"common",
		132
	],
	"./47ctf96j.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/47ctf96j.sc.entry.js",
		0,
		"common",
		133
	],
	"./4jebvdzz.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/4jebvdzz.entry.js",
		"common",
		10
	],
	"./4jebvdzz.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/4jebvdzz.sc.entry.js",
		"common",
		11
	],
	"./4m739wpj.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/4m739wpj.entry.js",
		"common",
		64
	],
	"./4m739wpj.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/4m739wpj.sc.entry.js",
		"common",
		65
	],
	"./4ovfvgj2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/4ovfvgj2.entry.js",
		0,
		"common",
		134
	],
	"./4ovfvgj2.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/4ovfvgj2.sc.entry.js",
		0,
		"common",
		135
	],
	"./4tejeecb.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/4tejeecb.entry.js",
		"common",
		66
	],
	"./4tejeecb.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/4tejeecb.sc.entry.js",
		"common",
		67
	],
	"./5ccusvgf.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5ccusvgf.entry.js",
		"common",
		68
	],
	"./5ccusvgf.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5ccusvgf.sc.entry.js",
		"common",
		69
	],
	"./5ey3bs99.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5ey3bs99.entry.js",
		"common",
		12
	],
	"./5ey3bs99.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5ey3bs99.sc.entry.js",
		"common",
		13
	],
	"./6f4biktp.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6f4biktp.entry.js",
		"common",
		70
	],
	"./6f4biktp.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6f4biktp.sc.entry.js",
		"common",
		71
	],
	"./8ldpeqpe.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/8ldpeqpe.entry.js",
		"common",
		14
	],
	"./8ldpeqpe.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/8ldpeqpe.sc.entry.js",
		"common",
		15
	],
	"./8q1e6dus.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/8q1e6dus.entry.js",
		"common",
		16
	],
	"./8q1e6dus.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/8q1e6dus.sc.entry.js",
		"common",
		17
	],
	"./96olk0dp.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/96olk0dp.entry.js",
		136
	],
	"./96olk0dp.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/96olk0dp.sc.entry.js",
		137
	],
	"./9rhd7ueu.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/9rhd7ueu.entry.js",
		0,
		"common",
		138
	],
	"./9rhd7ueu.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/9rhd7ueu.sc.entry.js",
		0,
		"common",
		139
	],
	"./9ynbzp83.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/9ynbzp83.entry.js",
		"common",
		18
	],
	"./9ynbzp83.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/9ynbzp83.sc.entry.js",
		"common",
		19
	],
	"./afjpklm4.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/afjpklm4.entry.js",
		"common",
		72
	],
	"./afjpklm4.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/afjpklm4.sc.entry.js",
		"common",
		73
	],
	"./bhtvuxzz.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bhtvuxzz.entry.js",
		0,
		"common",
		140
	],
	"./bhtvuxzz.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bhtvuxzz.sc.entry.js",
		0,
		"common",
		141
	],
	"./c2kiol1t.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/c2kiol1t.entry.js",
		"common",
		20
	],
	"./c2kiol1t.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/c2kiol1t.sc.entry.js",
		"common",
		21
	],
	"./ch8upsxn.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ch8upsxn.entry.js",
		0,
		"common",
		114
	],
	"./ch8upsxn.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ch8upsxn.sc.entry.js",
		0,
		"common",
		115
	],
	"./coytbtgb.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/coytbtgb.entry.js",
		"common",
		78
	],
	"./coytbtgb.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/coytbtgb.sc.entry.js",
		"common",
		79
	],
	"./cuwemyof.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/cuwemyof.entry.js",
		"common",
		80
	],
	"./cuwemyof.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/cuwemyof.sc.entry.js",
		"common",
		81
	],
	"./cyhnsxpk.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/cyhnsxpk.entry.js",
		0,
		"common",
		144
	],
	"./cyhnsxpk.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/cyhnsxpk.sc.entry.js",
		0,
		"common",
		145
	],
	"./dnpeoh7c.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/dnpeoh7c.entry.js",
		"common",
		22
	],
	"./dnpeoh7c.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/dnpeoh7c.sc.entry.js",
		"common",
		23
	],
	"./ejzmat7r.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ejzmat7r.entry.js",
		"common",
		74
	],
	"./ejzmat7r.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ejzmat7r.sc.entry.js",
		"common",
		75
	],
	"./fcbdrndu.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fcbdrndu.entry.js",
		"common",
		82
	],
	"./fcbdrndu.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fcbdrndu.sc.entry.js",
		"common",
		83
	],
	"./ffukzwt6.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ffukzwt6.entry.js",
		"common",
		122
	],
	"./ffukzwt6.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ffukzwt6.sc.entry.js",
		"common",
		123
	],
	"./fhznfhbd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fhznfhbd.entry.js",
		"common",
		24
	],
	"./fhznfhbd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fhznfhbd.sc.entry.js",
		"common",
		25
	],
	"./fiqi6app.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fiqi6app.entry.js",
		146
	],
	"./fiqi6app.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fiqi6app.sc.entry.js",
		147
	],
	"./g0yheybk.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/g0yheybk.entry.js",
		0,
		"common",
		148
	],
	"./g0yheybk.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/g0yheybk.sc.entry.js",
		0,
		"common",
		149
	],
	"./gvyg1bwh.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/gvyg1bwh.entry.js",
		"common",
		26
	],
	"./gvyg1bwh.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/gvyg1bwh.sc.entry.js",
		"common",
		27
	],
	"./i9lnulrx.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/i9lnulrx.entry.js",
		"common",
		28
	],
	"./i9lnulrx.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/i9lnulrx.sc.entry.js",
		"common",
		29
	],
	"./jdcptvrs.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jdcptvrs.entry.js",
		"common",
		84
	],
	"./jdcptvrs.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jdcptvrs.sc.entry.js",
		"common",
		85
	],
	"./jpkvsu5y.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jpkvsu5y.entry.js",
		"common",
		124
	],
	"./jpkvsu5y.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jpkvsu5y.sc.entry.js",
		"common",
		125
	],
	"./jtkjzkgg.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jtkjzkgg.entry.js",
		"common",
		30
	],
	"./jtkjzkgg.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jtkjzkgg.sc.entry.js",
		"common",
		31
	],
	"./jwqvpjte.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jwqvpjte.entry.js",
		"common",
		86
	],
	"./jwqvpjte.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jwqvpjte.sc.entry.js",
		"common",
		87
	],
	"./jyrjuxdj.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jyrjuxdj.entry.js",
		"common",
		32
	],
	"./jyrjuxdj.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jyrjuxdj.sc.entry.js",
		"common",
		33
	],
	"./jzmfoyaa.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jzmfoyaa.entry.js",
		"common",
		34
	],
	"./jzmfoyaa.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jzmfoyaa.sc.entry.js",
		"common",
		35
	],
	"./k1gbeuol.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/k1gbeuol.entry.js",
		"common",
		126
	],
	"./k1gbeuol.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/k1gbeuol.sc.entry.js",
		"common",
		127
	],
	"./lqvrsauo.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/lqvrsauo.entry.js",
		"common",
		88
	],
	"./lqvrsauo.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/lqvrsauo.sc.entry.js",
		"common",
		89
	],
	"./ly8zbpmk.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ly8zbpmk.entry.js",
		"common",
		36
	],
	"./ly8zbpmk.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ly8zbpmk.sc.entry.js",
		"common",
		37
	],
	"./mny78lhg.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mny78lhg.entry.js",
		0,
		"common",
		150
	],
	"./mny78lhg.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mny78lhg.sc.entry.js",
		0,
		"common",
		151
	],
	"./n361sgpa.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/n361sgpa.entry.js",
		"common",
		38
	],
	"./n361sgpa.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/n361sgpa.sc.entry.js",
		"common",
		39
	],
	"./nr6wcehx.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/nr6wcehx.entry.js",
		"common",
		40
	],
	"./nr6wcehx.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/nr6wcehx.sc.entry.js",
		"common",
		41
	],
	"./ntxo2f3d.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ntxo2f3d.entry.js",
		"common",
		42
	],
	"./ntxo2f3d.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ntxo2f3d.sc.entry.js",
		"common",
		43
	],
	"./nxacca4l.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/nxacca4l.entry.js",
		0,
		"common",
		152
	],
	"./nxacca4l.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/nxacca4l.sc.entry.js",
		0,
		"common",
		153
	],
	"./nxghvzhm.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/nxghvzhm.entry.js",
		"common",
		44
	],
	"./nxghvzhm.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/nxghvzhm.sc.entry.js",
		"common",
		45
	],
	"./oboc8zd4.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oboc8zd4.entry.js",
		"common",
		90
	],
	"./oboc8zd4.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oboc8zd4.sc.entry.js",
		"common",
		91
	],
	"./odqmlmdd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/odqmlmdd.entry.js",
		"common",
		46
	],
	"./odqmlmdd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/odqmlmdd.sc.entry.js",
		"common",
		47
	],
	"./psxwmesv.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/psxwmesv.entry.js",
		0,
		"common",
		154
	],
	"./psxwmesv.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/psxwmesv.sc.entry.js",
		0,
		"common",
		155
	],
	"./qtcvseqn.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qtcvseqn.entry.js",
		0,
		"common",
		156
	],
	"./qtcvseqn.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qtcvseqn.sc.entry.js",
		0,
		"common",
		157
	],
	"./qvwswew4.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qvwswew4.entry.js",
		"common",
		116
	],
	"./qvwswew4.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qvwswew4.sc.entry.js",
		"common",
		117
	],
	"./raunowwy.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/raunowwy.entry.js",
		"common",
		92
	],
	"./raunowwy.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/raunowwy.sc.entry.js",
		"common",
		93
	],
	"./s0ahgtia.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/s0ahgtia.entry.js",
		2,
		"common",
		158
	],
	"./s0ahgtia.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/s0ahgtia.sc.entry.js",
		2,
		"common",
		159
	],
	"./sdfyvdro.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/sdfyvdro.entry.js",
		"common",
		94
	],
	"./sdfyvdro.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/sdfyvdro.sc.entry.js",
		"common",
		95
	],
	"./sghmhl28.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/sghmhl28.entry.js",
		"common",
		48
	],
	"./sghmhl28.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/sghmhl28.sc.entry.js",
		"common",
		49
	],
	"./sjcqnbtt.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/sjcqnbtt.entry.js",
		"common",
		96
	],
	"./sjcqnbtt.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/sjcqnbtt.sc.entry.js",
		"common",
		97
	],
	"./t547wlk7.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/t547wlk7.entry.js",
		"common",
		118
	],
	"./t547wlk7.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/t547wlk7.sc.entry.js",
		"common",
		119
	],
	"./ta1bgxgm.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ta1bgxgm.entry.js",
		"common",
		98
	],
	"./ta1bgxgm.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ta1bgxgm.sc.entry.js",
		"common",
		99
	],
	"./tui62q7d.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tui62q7d.entry.js",
		"common",
		100
	],
	"./tui62q7d.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tui62q7d.sc.entry.js",
		"common",
		101
	],
	"./tylmm2yl.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tylmm2yl.entry.js",
		"common",
		102
	],
	"./tylmm2yl.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tylmm2yl.sc.entry.js",
		"common",
		103
	],
	"./uegz8gm3.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/uegz8gm3.entry.js",
		"common",
		104
	],
	"./uegz8gm3.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/uegz8gm3.sc.entry.js",
		"common",
		105
	],
	"./ugjythpm.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ugjythpm.entry.js",
		2,
		"common",
		160
	],
	"./ugjythpm.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ugjythpm.sc.entry.js",
		2,
		"common",
		161
	],
	"./unqw84tu.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/unqw84tu.entry.js",
		"common",
		128
	],
	"./unqw84tu.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/unqw84tu.sc.entry.js",
		"common",
		129
	],
	"./vjeei8vr.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vjeei8vr.entry.js",
		"common",
		76
	],
	"./vjeei8vr.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vjeei8vr.sc.entry.js",
		"common",
		77
	],
	"./wem5ffil.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wem5ffil.entry.js",
		0,
		"common",
		162
	],
	"./wem5ffil.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wem5ffil.sc.entry.js",
		0,
		"common",
		163
	],
	"./wy4rjeqs.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wy4rjeqs.entry.js",
		0,
		"common",
		120
	],
	"./wy4rjeqs.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wy4rjeqs.sc.entry.js",
		0,
		"common",
		121
	],
	"./xbafxwto.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xbafxwto.entry.js",
		0,
		"common",
		164
	],
	"./xbafxwto.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xbafxwto.sc.entry.js",
		0,
		"common",
		165
	],
	"./xfbndl84.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xfbndl84.entry.js",
		"common",
		50
	],
	"./xfbndl84.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xfbndl84.sc.entry.js",
		"common",
		51
	],
	"./xgnma4yj.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xgnma4yj.entry.js",
		"common",
		106
	],
	"./xgnma4yj.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xgnma4yj.sc.entry.js",
		"common",
		107
	],
	"./xrxaow8a.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xrxaow8a.entry.js",
		"common",
		108
	],
	"./xrxaow8a.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xrxaow8a.sc.entry.js",
		"common",
		109
	],
	"./ycyyhg01.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ycyyhg01.entry.js",
		"common",
		110
	],
	"./ycyyhg01.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ycyyhg01.sc.entry.js",
		"common",
		111
	],
	"./ygh0szo0.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ygh0szo0.entry.js",
		"common",
		52
	],
	"./ygh0szo0.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ygh0szo0.sc.entry.js",
		"common",
		53
	],
	"./z9eemkqi.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/z9eemkqi.entry.js",
		"common",
		54
	],
	"./z9eemkqi.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/z9eemkqi.sc.entry.js",
		"common",
		55
	],
	"./z9nt6ntd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/z9nt6ntd.entry.js",
		"common",
		130
	],
	"./z9nt6ntd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/z9nt6ntd.sc.entry.js",
		"common",
		131
	],
	"./zktscnoo.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zktscnoo.entry.js",
		"common",
		112
	],
	"./zktscnoo.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zktscnoo.sc.entry.js",
		"common",
		113
	],
	"./zykaqnfi.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zykaqnfi.entry.js",
		"common",
		56
	],
	"./zykaqnfi.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zykaqnfi.sc.entry.js",
		"common",
		57
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm/es5/build lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"../event/event.module": [
		"./src/app/event/event.module.ts",
		"event-event-module"
	],
	"../group/group.module": [
		"./src/app/group/group.module.ts",
		"default~group-group-module~tabs-tabs-module",
		"common"
	],
	"../post/post.module": [
		"./src/app/post/post.module.ts",
		"default~post-post-module~tabs-tabs-module",
		"common"
	],
	"./auth/login/login.module": [
		"./src/app/auth/login/login.module.ts",
		"auth-login-login-module"
	],
	"./auth/register/register.module": [
		"./src/app/auth/register/register.module.ts",
		"auth-register-register-module"
	],
	"./home/home.module": [
		"./src/app/home/home.module.ts",
		"home-home-module"
	],
	"./menu/menu.module": [
		"./src/app/menu/menu.module.ts",
		"menu-menu-module"
	],
	"./tabs/tabs.module": [
		"./src/app/tabs/tabs.module.ts",
		"default~post-post-module~tabs-tabs-module",
		"default~group-group-module~tabs-tabs-module",
		"common",
		"tabs-tabs-module"
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _auth_auth_guard_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./auth/auth-guard.service */ "./src/app/auth/auth-guard.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var routes = [
    { path: '', redirectTo: 'login', pathMatch: 'full' },
    { path: 'home', loadChildren: './home/home.module#HomePageModule', canActivate: [_auth_auth_guard_service__WEBPACK_IMPORTED_MODULE_2__["AuthGuardService"]] },
    { path: 'login', loadChildren: './auth/login/login.module#LoginPageModule' },
    { path: 'register', loadChildren: './auth/register/register.module#RegisterPageModule' },
    { path: 'tabs', loadChildren: './tabs/tabs.module#TabsPageModule' },
    { path: 'menu', loadChildren: './menu/menu.module#MenuPageModule', canActivate: [_auth_auth_guard_service__WEBPACK_IMPORTED_MODULE_2__["AuthGuardService"]] },
];
var AppRoutingModule = /** @class */ (function () {
    // @ts-ignore
    function AppRoutingModule() {
    }
    AppRoutingModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
        })
        // @ts-ignore
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-app>\n  <ion-router-outlet></ion-router-outlet>\n</ion-app>\n"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _auth_auth_service_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./auth/auth-service.service */ "./src/app/auth/auth-service.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};






var AppComponent = /** @class */ (function () {
    function AppComponent(platform, splashScreen, statusBar, authService, router) {
        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.authService = authService;
        this.router = router;
        this.initializeApp();
    }
    AppComponent.prototype.initializeApp = function () {
        var _this = this;
        this.platform.ready().then(function () {
            _this.statusBar.styleDefault();
            _this.splashScreen.hide();
            _this.authService.autoAuthUser();
            if (_this.authService.getIsAuth()) {
                _this.router.navigate(['menu/menu']);
            }
            else {
                _this.router.navigate(['login']);
            }
        });
    };
    AppComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html")
        }),
        __metadata("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["Platform"],
            _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_2__["SplashScreen"],
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_3__["StatusBar"],
            _auth_auth_service_service__WEBPACK_IMPORTED_MODULE_4__["AuthServiceService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _auth_auth_service_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./auth/auth-service.service */ "./src/app/auth/auth-service.service.ts");
/* harmony import */ var _ionic_Storage__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/Storage */ "./node_modules/@ionic/Storage/fesm5/ionic-storage.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _auth_auth_interceptor__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./auth/auth-interceptor */ "./src/app/auth/auth-interceptor.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};













var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]
            ],
            entryComponents: [],
            imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"].forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_8__["AppRoutingModule"],
                _ionic_Storage__WEBPACK_IMPORTED_MODULE_10__["IonicStorageModule"].forRoot(), _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClientModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_11__["FormsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_11__["ReactiveFormsModule"]],
            providers: [
                _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__["StatusBar"],
                _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__["SplashScreen"],
                { provide: _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouteReuseStrategy"], useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicRouteStrategy"] },
                { provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HTTP_INTERCEPTORS"], useClass: _auth_auth_interceptor__WEBPACK_IMPORTED_MODULE_12__["AuthInterceptor"], multi: true },
                _auth_auth_service_service__WEBPACK_IMPORTED_MODULE_9__["AuthServiceService"]
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/auth/auth-guard.service.ts":
/*!********************************************!*\
  !*** ./src/app/auth/auth-guard.service.ts ***!
  \********************************************/
/*! exports provided: AuthGuardService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthGuardService", function() { return AuthGuardService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _auth_service_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./auth-service.service */ "./src/app/auth/auth-service.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var AuthGuardService = /** @class */ (function () {
    function AuthGuardService(authService, router) {
        this.authService = authService;
        this.router = router;
    }
    AuthGuardService.prototype.canActivate = function (route, state) {
        var isAuth = this.authService.getIsAuth();
        if (!isAuth) {
            this.router.navigate(['/login']);
        }
        return true;
    };
    AuthGuardService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_auth_service_service__WEBPACK_IMPORTED_MODULE_1__["AuthServiceService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], AuthGuardService);
    return AuthGuardService;
}());



/***/ }),

/***/ "./src/app/auth/auth-interceptor.ts":
/*!******************************************!*\
  !*** ./src/app/auth/auth-interceptor.ts ***!
  \******************************************/
/*! exports provided: AuthInterceptor */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthInterceptor", function() { return AuthInterceptor; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _auth_service_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./auth-service.service */ "./src/app/auth/auth-service.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var AuthInterceptor = /** @class */ (function () {
    function AuthInterceptor(authService) {
        this.authService = authService;
    }
    AuthInterceptor.prototype.intercept = function (req, next) {
        var authToken = this.authService.getToken();
        var authRequest = req.clone({
            headers: req.headers.set('authorization', 'Bearer ' + authToken)
        });
        return next.handle(authRequest);
    };
    AuthInterceptor = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])(),
        __metadata("design:paramtypes", [_auth_service_service__WEBPACK_IMPORTED_MODULE_1__["AuthServiceService"]])
    ], AuthInterceptor);
    return AuthInterceptor;
}());



/***/ }),

/***/ "./src/app/auth/auth-service.service.ts":
/*!**********************************************!*\
  !*** ./src/app/auth/auth-service.service.ts ***!
  \**********************************************/
/*! exports provided: AuthServiceService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthServiceService", function() { return AuthServiceService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var AuthServiceService = /** @class */ (function () {
    function AuthServiceService(http, router) {
        this.http = http;
        this.router = router;
        this.isAuthenticated = false;
        this.authStatusListener = new rxjs__WEBPACK_IMPORTED_MODULE_1__["Subject"]();
    }
    AuthServiceService.prototype.createUser = function (email, image, password, username, department, registration) {
        var _this = this;
        // const authData: {email: email, password: password};
        var userData = new FormData();
        userData.append('email', email);
        userData.append('password', password);
        userData.append('username', username);
        userData.append('image', image, email);
        userData.append('department', department);
        userData.append('registration', registration);
        console.log(userData);
        this.http.post('http://localhost:3000/api/user/signup', userData)
            .subscribe(function (response) {
            console.log(response);
            _this.router.navigate(['/login']);
        });
    };
    AuthServiceService.prototype.getName = function () {
        return localStorage.getItem('username');
    };
    AuthServiceService.prototype.login = function (email, password) {
        var _this = this;
        // const authData: AuthData = {email: email, password: password};
        this.http.post('http://192.168.10.7:3000/api/user/login', { email: email, password: password })
            .subscribe(function (response) {
            var token = response.token;
            console.log(response);
            _this.token = token;
            if (token) {
                var expiresInDuration = response.expiresIn;
                _this.setAuthTimer(expiresInDuration);
                _this.isAuthenticated = true;
                _this.userId = response.userId;
                _this.userN = response.username;
                _this.authStatusListener.next(true);
                console.log('here');
                var now = new Date();
                var expirationDate = new Date(now.getTime() + (expiresInDuration * 1000));
                console.log(expirationDate);
                console.log(response.profileimg);
                _this.saveAuthData(token, expirationDate, _this.userId, _this.userN, response.department, response.profileimg);
                _this.router.navigate(['/menu/menu']).then();
            }
        }, function (error) {
            console.log('error');
            _this.router.navigate(['/']).then();
        });
    };
    AuthServiceService.prototype.getIsAuth = function () {
        return this.isAuthenticated;
    };
    AuthServiceService.prototype.getAuthStatusListener = function () {
        return this.authStatusListener.asObservable();
    };
    AuthServiceService.prototype.getUserId = function () {
        return this.userId;
    };
    AuthServiceService.prototype.getToken = function () {
        return this.token;
    };
    AuthServiceService.prototype.autoAuthUser = function () {
        var authInformation = this.getAuthData();
        if (!authInformation) {
            return;
        }
        var now = new Date();
        var expiresIn = authInformation.expirationDate.getTime() - now.getTime();
        if (expiresIn > 0) {
            this.token = authInformation.token;
            this.isAuthenticated = true;
            this.userId = authInformation.userId;
            this.setAuthTimer(expiresIn / 1000);
            this.authStatusListener.next(true);
        }
    };
    AuthServiceService.prototype.setAuthTimer = function (duration) {
        var _this = this;
        console.log('Setting timer:' + duration);
        this.tokenTimer = setTimeout(function () {
            _this.logout();
        }, duration * 1000);
    };
    AuthServiceService.prototype.logout = function () {
        this.token = null;
        this.isAuthenticated = false;
        this.authStatusListener.next(false);
        this.userId = null;
        this.userN = null;
        clearTimeout(this.tokenTimer);
        this.clearAuthData();
        this.router.navigate(['/']);
    };
    AuthServiceService.prototype.saveAuthData = function (token, expirationDate, userId, userNam, department, profileimg) {
        localStorage.setItem('token', token);
        localStorage.setItem('expiration', expirationDate.toISOString());
        localStorage.setItem('userId', userId);
        localStorage.setItem('username', userNam);
        localStorage.setItem('department', department);
        localStorage.setItem('profileimg', profileimg);
    };
    AuthServiceService.prototype.clearAuthData = function () {
        localStorage.removeItem('token');
        localStorage.removeItem('expiration');
        localStorage.removeItem('userId');
        localStorage.removeItem('username');
        localStorage.removeItem('department');
        localStorage.removeItem('profileimg');
    };
    AuthServiceService.prototype.getAuthData = function () {
        var token = localStorage.getItem('token');
        var expirationDate = localStorage.getItem('expiration');
        var userId = localStorage.getItem('userId');
        if (!token || !expirationDate) {
            return;
        }
        return {
            token: token,
            expirationDate: new Date(expirationDate),
            userId: userId
        };
    };
    AuthServiceService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]])
    ], AuthServiceService);
    return AuthServiceService;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! F:\comsats_social_mobile\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map