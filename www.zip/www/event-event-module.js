(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["event-event-module"],{

/***/ "./src/app/event/event.module.ts":
/*!***************************************!*\
  !*** ./src/app/event/event.module.ts ***!
  \***************************************/
/*! exports provided: EventPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EventPageModule", function() { return EventPageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _event_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./event.page */ "./src/app/event/event.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var routes = [
    {
        path: '',
        component: _event_page__WEBPACK_IMPORTED_MODULE_5__["EventPage"]
    }
];
var EventPageModule = /** @class */ (function () {
    function EventPageModule() {
    }
    EventPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routes)
            ],
            declarations: [_event_page__WEBPACK_IMPORTED_MODULE_5__["EventPage"]]
        })
    ], EventPageModule);
    return EventPageModule;
}());



/***/ }),

/***/ "./src/app/event/event.page.html":
/*!***************************************!*\
  !*** ./src/app/event/event.page.html ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n  <ion-card *ngFor=\"let event of events\">\n\n    <ion-card-header>\n      <ion-list style=\"list-style: none; display: flex;\">\n        <ion-item lines=\"none\">\n          <!--<ion-avatar slot=\"start\">-->\n          <!--<img [src]= \"post.profileimg\">-->\n          <!--</ion-avatar>-->\n        </ion-item>\n        <ion-item>\n          <ion-card-title>{{event.username}}</ion-card-title>\n        </ion-item>\n\n        <ion-item>\n          <ion-card-subtitle>{{ event.eventname }}</ion-card-subtitle>\n        </ion-item>\n      </ion-list>\n    </ion-card-header>\n    <!--<img [hidden]=\"!post.imagePath\" [src]=\"post.imagePath\" [alt]=\"post.title\" >-->\n    <ion-card-content>\n      <strong>{{event.description}}</strong>\n      <br/>\n      <strong>Event Date: </strong>{{ event.eventdate | date:'MMM dd, yyyy' }}\n    </ion-card-content>\n  </ion-card>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/event/event.page.scss":
/*!***************************************!*\
  !*** ./src/app/event/event.page.scss ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2V2ZW50L2V2ZW50LnBhZ2Uuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/event/event.page.ts":
/*!*************************************!*\
  !*** ./src/app/event/event.page.ts ***!
  \*************************************/
/*! exports provided: EventPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EventPage", function() { return EventPage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _events_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./events.service */ "./src/app/event/events.service.ts");
/* harmony import */ var _auth_auth_service_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../auth/auth-service.service */ "./src/app/auth/auth-service.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var EventPage = /** @class */ (function () {
    function EventPage(eventsService, authService) {
        this.eventsService = eventsService;
        this.authService = authService;
        this.events = [];
        this.isLoading = false;
        this.userIsAuthenticated = false;
    }
    EventPage.prototype.ngOnInit = function () {
        var _this = this;
        this.isLoading = true;
        this.eventsService.getEvents();
        this.userId = this.authService.getUserId();
        this.username = this.authService.getName();
        this.eventsSub = this.eventsService.getEventUpdateListener()
            .subscribe(function (eventData) {
            _this.isLoading = false;
            // this.totalEvents = eventData.eventCount;
            _this.username = _this.authService.getName();
            _this.events = eventData.events;
            console.log(_this.events);
        });
        this.userIsAuthenticated = this.authService.getIsAuth();
        this.authStatusSub = this.authService
            .getAuthStatusListener()
            .subscribe(function (isAuthenticated) {
            _this.userIsAuthenticated = isAuthenticated;
            _this.userId = _this.authService.getUserId();
        });
    };
    EventPage.prototype.ngOnDestroy = function () {
        this.eventsSub.unsubscribe();
        this.authStatusSub.unsubscribe();
    };
    EventPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-event',
            template: __webpack_require__(/*! ./event.page.html */ "./src/app/event/event.page.html"),
            styles: [__webpack_require__(/*! ./event.page.scss */ "./src/app/event/event.page.scss")]
        }),
        __metadata("design:paramtypes", [_events_service__WEBPACK_IMPORTED_MODULE_1__["EventsService"],
            _auth_auth_service_service__WEBPACK_IMPORTED_MODULE_2__["AuthServiceService"]])
    ], EventPage);
    return EventPage;
}());



/***/ }),

/***/ "./src/app/event/events.service.ts":
/*!*****************************************!*\
  !*** ./src/app/event/events.service.ts ***!
  \*****************************************/
/*! exports provided: EventsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EventsService", function() { return EventsService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var EventsService = /** @class */ (function () {
    function EventsService(http, router) {
        this.http = http;
        this.router = router;
        this.username = '';
        this.events = [];
        this.posts = [];
        this.eventsUpdated = new rxjs__WEBPACK_IMPORTED_MODULE_1__["Subject"]();
        this.postsUpdated = new rxjs__WEBPACK_IMPORTED_MODULE_1__["Subject"]();
    }
    EventsService.prototype.getPosts = function (id) {
        var _this = this;
        console.log('eventinservicee' + id);
        this.http.get('http://localhost:3000/api/events/' + id)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (postData) {
            return { posts: postData.posts.map(function (post) {
                    return {
                        title: post.title,
                        content: post.content,
                        username: post.username,
                        creator: post.creator,
                        likes: post.likes,
                        id: post._id,
                        commentsNo: post.commentsNo,
                        comments: post.comments,
                        profileimg: post.profileimg,
                        dislikes: post.dislikes,
                        createdAt: post.createdAt,
                        imagePath: post.imagePath
                    };
                }) };
        }))
            .subscribe(function (transformedEventPost) {
            _this.posts = transformedEventPost.posts;
            _this.postsUpdated.next({
                posts: _this.posts.slice()
            });
        });
    };
    EventsService.prototype.getPostUpdateListener = function () {
        return this.postsUpdated.asObservable();
    };
    EventsService.prototype.getEvents = function () {
        var _this = this;
        // const queryParams = `?pagesize=${eventsPerPage}&page=${currentPage}`; // `` backtips are for dynamically adding values into strings
        this.http
            .get('http://localhost:3000/api/events')
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (eventData) {
            return { events: eventData.events.map(function (event) {
                    return {
                        eventname: event.eventname,
                        description: event.description,
                        id: event._id,
                        eventdate: event.eventdate,
                        username: event.username,
                        creator: event.eventcreator,
                        category: event.category,
                    };
                }), maxEvents: eventData.maxEvents };
        })) // change rterieving data
            .subscribe(function (transformedEventData) {
            _this.events = transformedEventData.events;
            _this.eventsUpdated.next({
                events: _this.events.slice(),
                eventCount: transformedEventData.maxEvents
            });
        }); // subscribe is to liosten
    };
    EventsService.prototype.getJoinedEvents = function () {
        var _this = this;
        this.http
            .get('http://localhost:3000/api/events/joinedevents')
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (eventData) {
            return { events: eventData.events.map(function (event) {
                    return {
                        eventname: event.eventname,
                        // description: group.description,
                        id: event._id,
                    };
                }), maxEvents: eventData.maxEvents };
        })) // change rterieving data
            .subscribe(function (transformedEventData) {
            _this.events = transformedEventData.events;
            _this.eventsUpdated.next({
                events: _this.events.slice(),
                eventCount: transformedEventData.maxEvents
            });
        }); // subscribe is to liosten
    };
    EventsService.prototype.getEventUpdateListener = function () {
        return this.eventsUpdated.asObservable();
    };
    EventsService.prototype.addEvent = function (eventname, category, description, eventdate, username) {
        var _this = this;
        return this.http
            .post('http://localhost:3000/api/events', { eventname: eventname, description: description, category: category, eventdate: eventdate, username: username })
            .subscribe(function (responseData) {
            _this.router.navigate(['/eventlist']);
        });
    };
    EventsService.prototype.addPost = function (id, title, content, image) {
        var _this = this;
        var postData = new FormData();
        postData.append('title', title);
        postData.append('content', content);
        postData.append('image', image, title);
        // postData.append('username', localStorage.getItem('username'));
        // postData.append('profileimg', profileimg);
        console.log(postData);
        this.http
            .put('http://localhost:3000/api/events/addeventPost/' + id, postData)
            .subscribe(function (responseData) {
            _this.router.navigate(['/eventpage/' + id]);
        });
    };
    EventsService.prototype.joinEvent = function (id) {
        var _this = this;
        // @ts-ignore
        this.http
            .put('http://localhost:3000/api/events/adduser/' + id)
            .subscribe(function (responseData) {
            _this.router.navigate(['/eventpage/' + id]);
        });
    };
    EventsService.prototype.likePost = function (postid, eventid) {
        var eventData = {
            eventid: eventid,
            postid: postid
        };
        // @ts-ignore
        return this.http.put('http://localhost:3000/api/events/likeeventpost', eventData);
    };
    //
    EventsService.prototype.dislikePost = function (postid, eventid) {
        var eventData = {
            eventid: eventid,
            postid: postid
        };
        // @ts-ignore
        return this.http.put('http://localhost:3000/api/events/dislikeeventpost', eventData);
    };
    EventsService.prototype.addComment = function (postid, eventid, comment) {
        var eventData = {
            eventid: eventid,
            postid: postid,
            comment: comment
        };
        // @ts-ignore
        return this.http.put('http://localhost:3000/api/events/commenteventpost', eventData);
    };
    EventsService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({ providedIn: 'root' }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]])
    ], EventsService);
    return EventsService;
}());



/***/ })

}]);
//# sourceMappingURL=event-event-module.js.map