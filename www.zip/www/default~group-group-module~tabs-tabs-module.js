(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~group-group-module~tabs-tabs-module"],{

/***/ "./src/app/group/group.module.ts":
/*!***************************************!*\
  !*** ./src/app/group/group.module.ts ***!
  \***************************************/
/*! exports provided: GroupPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GroupPageModule", function() { return GroupPageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _group_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./group.page */ "./src/app/group/group.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var routes = [
    {
        path: '',
        component: _group_page__WEBPACK_IMPORTED_MODULE_5__["GroupPage"]
    }
];
var GroupPageModule = /** @class */ (function () {
    function GroupPageModule() {
    }
    GroupPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routes)
            ],
            declarations: [_group_page__WEBPACK_IMPORTED_MODULE_5__["GroupPage"]]
        })
    ], GroupPageModule);
    return GroupPageModule;
}());



/***/ }),

/***/ "./src/app/group/group.page.html":
/*!***************************************!*\
  !*** ./src/app/group/group.page.html ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n  <ion-card>\n    <ion-row justify-content-center>\n      <ion-col align-self-center size-md=\"6\" size-lg=\"5\" size-xs=\"12\">\n        <form #form=\"ngForm\" novalidate (ngSubmit)=\"onSaveGroup(form)\" >\n\n          <ion-input\n                  type=\"text\"\n                  required\n                  [(ngModel)]=\"name\"\n                  ngModel\n                  #titleInput=\"ngModel\"\n                  name=\"name\"\n                  placeholder=\"Name\">\n          </ion-input>\n\n          <ion-input\n                  type=\"text\"\n                  rows=\"4\"\n                  required\n                  [(ngModel)]=\"description\"\n                  ngModel\n                  #contentInput=\"ngModel\"\n                  name=\"description\"\n                  placeholder=\"Group Description\"\n          ></ion-input>\n\n          <ion-select\n                  required\n                  [(ngModel)]=\"cname\"\n                  ngModel\n                  placeholder=\"Category\"\n                  #cnameInput = \"ngModel\"\n                  name = \"cname\">\n\n            <ion-select-option *ngFor=\"let category of categories\" [value]=\"category\">\n              {{category}}\n            </ion-select-option>\n\n          </ion-select>\n\n          <ion-button\n                  type=\"submit\">Save Group</ion-button>\n        </form>\n      </ion-col></ion-row>\n  </ion-card>\n  <ion-card *ngFor=\"let group of groups\">\n\n    <ion-card-header>\n      <ion-list style=\"list-style: none; display: flex;\">\n        <ion-item lines=\"none\">\n          <!--<ion-avatar slot=\"start\">-->\n            <!--<img [src]= \"post.profileimg\">-->\n          <!--</ion-avatar>-->\n        </ion-item>\n        <ion-item>\n          <ion-card-title>{{group.username}}</ion-card-title>\n        </ion-item>\n\n        <ion-item>\n          <ion-card-subtitle>{{ group.groupname }}</ion-card-subtitle>\n        </ion-item>\n      </ion-list>\n    </ion-card-header>\n    <!--<img [hidden]=\"!post.imagePath\" [src]=\"post.imagePath\" [alt]=\"post.title\" >-->\n    <ion-card-content>\n      <strong>{{group.description}}</strong>\n      <br/>\n      <!--<strong>Date: </strong>{{ post.createdAt | date:'MMM dd, yyyy' }}-->\n    </ion-card-content>\n  </ion-card>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/group/group.page.scss":
/*!***************************************!*\
  !*** ./src/app/group/group.page.scss ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2dyb3VwL2dyb3VwLnBhZ2Uuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/group/group.page.ts":
/*!*************************************!*\
  !*** ./src/app/group/group.page.ts ***!
  \*************************************/
/*! exports provided: GroupPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GroupPage", function() { return GroupPage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _groups_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./groups.service */ "./src/app/group/groups.service.ts");
/* harmony import */ var _auth_auth_service_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../auth/auth-service.service */ "./src/app/auth/auth-service.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var GroupPage = /** @class */ (function () {
    function GroupPage(groupsService, authService) {
        this.groupsService = groupsService;
        this.authService = authService;
        this.groups = [];
        this.isLoading = false;
        this.totalGroups = 0;
        this.groupsPerPage = 5;
        this.currentPage = 1;
        this.userIsAuthenticated = false;
        this.categories = ['General', localStorage.getItem('department')];
    }
    GroupPage.prototype.ngOnInit = function () {
        var _this = this;
        this.isLoading = true;
        this.groupsService.getGroups();
        this.userId = this.authService.getUserId();
        this.username = this.authService.getName();
        this.groupsSub = this.groupsService.getGroupUpdateListener()
            .subscribe(function (groupData) {
            _this.isLoading = false;
            _this.totalGroups = groupData.groupCount;
            _this.username = _this.authService.getName();
            _this.groups = groupData.groups;
            console.log(_this.groups);
        });
        this.userIsAuthenticated = this.authService.getIsAuth();
        this.authStatusSub = this.authService
            .getAuthStatusListener()
            .subscribe(function (isAuthenticated) {
            _this.userIsAuthenticated = isAuthenticated;
            _this.userId = _this.authService.getUserId();
        });
    };
    GroupPage.prototype.onSaveGroup = function (form) {
        var _this = this;
        console.log(form.value.title + ' ' + form.value.content + ' ' + form.value.cname);
        this.groupsService.addGroup(form.value.name, form.value.cname, form.value.description, localStorage.getItem('username')).subscribe(function () {
            _this.groupsService.getGroups();
        });
        form.reset();
    };
    GroupPage.prototype.ngOnDestroy = function () {
        this.groupsSub.unsubscribe();
        this.authStatusSub.unsubscribe();
    };
    GroupPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-group',
            template: __webpack_require__(/*! ./group.page.html */ "./src/app/group/group.page.html"),
            styles: [__webpack_require__(/*! ./group.page.scss */ "./src/app/group/group.page.scss")]
        }),
        __metadata("design:paramtypes", [_groups_service__WEBPACK_IMPORTED_MODULE_1__["GroupsService"], _auth_auth_service_service__WEBPACK_IMPORTED_MODULE_2__["AuthServiceService"]])
    ], GroupPage);
    return GroupPage;
}());



/***/ }),

/***/ "./src/app/group/groups.service.ts":
/*!*****************************************!*\
  !*** ./src/app/group/groups.service.ts ***!
  \*****************************************/
/*! exports provided: GroupsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GroupsService", function() { return GroupsService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var GroupsService = /** @class */ (function () {
    function GroupsService(http, router) {
        this.http = http;
        this.router = router;
        this.username = '';
        this.groups = [];
        this.posts = [];
        this.groupsUpdated = new rxjs__WEBPACK_IMPORTED_MODULE_1__["Subject"]();
        this.postsUpdated = new rxjs__WEBPACK_IMPORTED_MODULE_1__["Subject"]();
    }
    GroupsService.prototype.getPosts = function (id) {
        var _this = this;
        console.log('inservicee' + id);
        this.http.get('http://localhost:3000/api/groups/' + id)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (postData) {
            return { posts: postData.posts.map(function (post) {
                    return {
                        title: post.title,
                        content: post.content,
                        username: post.username,
                        creator: post.creator,
                        likes: post.likes,
                        commentsNo: post.commentsNo,
                        comments: post.comments,
                        dislikes: post.dislikes,
                        profileimg: post.profileimg,
                        id: post._id,
                        createdAt: post.createdAt,
                        imagePath: post.imagePath
                    };
                }) };
        }))
            .subscribe(function (transformedGroupPost) {
            _this.posts = transformedGroupPost.posts;
            _this.postsUpdated.next({
                posts: _this.posts.slice()
            });
        });
    };
    GroupsService.prototype.getPostUpdateListener = function () {
        return this.postsUpdated.asObservable();
    };
    GroupsService.prototype.getGroups = function () {
        var _this = this;
        // const queryParams = `?pagesize=${groupsPerPage}&page=${currentPage}`; // `` backtips are for dynamically adding values into strings
        this.http
            .get('http://192.168.10.7:3000/api/groups')
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (groupData) {
            return { groups: groupData.groups.map(function (group) {
                    return {
                        groupname: group.groupname,
                        description: group.description,
                        id: group._id,
                        username: group.username,
                        creator: group.groupcreator,
                        category: group.category,
                    };
                }), maxGroups: groupData.maxGroups };
        })) // change rterieving data
            .subscribe(function (transformedGroupData) {
            _this.groups = transformedGroupData.groups;
            _this.groupsUpdated.next({
                groups: _this.groups.slice(),
                groupCount: transformedGroupData.maxGroups
            });
        }); // subscribe is to liosten
    };
    GroupsService.prototype.getJoinedGroups = function () {
        var _this = this;
        this.http
            .get('http://localhost:3000/api/groups/joinedgroups')
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (groupData) {
            return { groups: groupData.groups.map(function (group) {
                    return {
                        groupname: group.groupname,
                        // description: group.description,
                        id: group._id,
                    };
                }), maxGroups: groupData.maxGroups };
        })) // change rterieving data
            .subscribe(function (transformedGroupData) {
            _this.groups = transformedGroupData.groups;
            _this.groupsUpdated.next({
                groups: _this.groups.slice(),
                groupCount: transformedGroupData.maxGroups
            });
        }); // subscribe is to liosten
    };
    GroupsService.prototype.deletePost = function (groupId, postId) {
        var queryParams = "?groupid=" + groupId + "&postid=" + postId;
        return this.http
            .delete('http://localhost:3000/api/groups/delete' + queryParams);
    };
    GroupsService.prototype.getGroupUpdateListener = function () {
        return this.groupsUpdated.asObservable();
    };
    GroupsService.prototype.addGroup = function (groupname, category, description, username) {
        return this.http
            .post('http://192.168.10.7:3000/api/groups', { groupname: groupname, description: description, category: category, username: username });
    };
    GroupsService.prototype.addPost = function (id, title, content, image) {
        var _this = this;
        var postData = new FormData();
        postData.append('title', title);
        postData.append('content', content);
        postData.append('image', image, title);
        // postData.append('username', localStorage.getItem('username'));
        // postData.append('profileimg', profileimg);
        console.log(postData);
        this.http
            .put('http://localhost:3000/api/groups/addgroupPost/' + id, postData)
            .subscribe(function (responseData) {
            _this.router.navigate(['/grouplist']);
        });
    };
    GroupsService.prototype.joinGroup = function (id) {
        var _this = this;
        // @ts-ignore
        this.http
            .put('http://localhost:3000/api/groups/adduser/' + id)
            .subscribe(function (responseData) {
            _this.router.navigate(['/grouppage/' + id]);
        });
    };
    GroupsService.prototype.likePost = function (postid, groupid) {
        var groupData = {
            groupid: groupid,
            postid: postid
        };
        // @ts-ignore
        return this.http.put('http://localhost:3000/api/groups/likegrouppost', groupData);
    };
    //
    GroupsService.prototype.dislikePost = function (postid, groupid) {
        var groupData = {
            groupid: groupid,
            postid: postid
        };
        // @ts-ignore
        return this.http.put('http://localhost:3000/api/groups/dislikegrouppost', groupData);
    };
    GroupsService.prototype.addComment = function (postid, groupid, comment) {
        var groupData = {
            groupid: groupid,
            postid: postid,
            comment: comment
        };
        // @ts-ignore
        return this.http.put('http://localhost:3000/api/groups/commentgrouppost', groupData);
    };
    GroupsService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({ providedIn: 'root' }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]])
    ], GroupsService);
    return GroupsService;
}());



/***/ })

}]);
//# sourceMappingURL=default~group-group-module~tabs-tabs-module.js.map